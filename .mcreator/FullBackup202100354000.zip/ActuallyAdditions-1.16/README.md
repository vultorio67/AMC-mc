## It's a Minecraft Mod! [![CurseForge](http://cf.way2muchnoise.eu/full_actually-additions_downloads.svg)](https://minecraft.curseforge.com/projects/actually-additions) [![CurseForge](http://cf.way2muchnoise.eu/versions/actually-additions.svg)](https://minecraft.curseforge.com/projects/actually-additions)

For more information, visit the main CurseForge Page by [clicking here](http://minecraft.curseforge.com/projects/actually-additions)!

Jenkins: [Click here](https://ci.ellpeck.de/blue/organizations/jenkins/ActuallyAdditions/)      
Maven: [Click here](https://maven.ellpeck.de/de/ellpeck/actuallyadditions/)

![](https://raw.githubusercontent.com/Ellpeck/ActuallyAdditions/main/pics/logo.png)
